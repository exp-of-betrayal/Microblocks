from flask import Flask, request, render_template, redirect
import sqlite3
import os

app = Flask(__name__, template_folder=os.getcwd() + "\\simple front")


def is_registry(nick):
    connection = sqlite3.connect("database.sqlite")
    cursor = connection.cursor()
    data = cursor.execute("SELECT * FROM data WHERE login = (?)", (nick,))
    if data is None:
        return False
    else:
        return True


def data_correctly(nick, password):
    connection = sqlite3.connect("database.sqlite")
    cursor = connection.cursor()
    data = cursor.execute(
        "SELECT * FROM data WHERE login = ? and password = ?;", nick, password)
    if is_registry(nick) is False:
        return "login is incorrect"

    if data == "None":
        return "login is incorrect"
    else:
        return "accepted"


def write_bd(nick, password):
    connection = sqlite3.connect("database.sqlite")
    cursor = connection.cursor()
    cursor.execute(
        "INSERT INTO data (`login`, `password`) VALUES (?, ?)", nick, password)
    connection.commit()
    return None


@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template("Main_page.html")


@app.route("/search", methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        if request.form.get("username"):
            nick = request.form.get("username")
            href_to = str(request.base_url) + "/acc/@" + str(nick)
            return redirect(href_to, code=302)

        if request.form.get("postteg"):
            teg = request.form.get("postteg")
            href = str(request.base_url) + "/tegs/" + str(teg)
            return redirect(href, code=302)

    return render_template("search.html")


@app.route('/search/acc/@<id>')
def get_acc(id):
    return f'''searching @{id}'''


@app.route('/search/tegs/<tegs>')
def get_tegs(tegs):
    return f'''searching tegs : #{tegs}'''


@app.route("/registration_or_autorization", methods=['GET', 'POST'])
def reg_and_log():
    if request.method == "POST":
        if request.form.get("nick"):  # registration
            print("reg-form")
            nick, password, confirm = request.form.values()
            if password != confirm:
                return render_template("reg-and-log.html",
                                       log="password != confirm")
            else:
                if is_registry(nick):
                    return render_template("reg-and-log.html",
                                           log="already is")
                else:
                    write_bd(nick)
                    return render_template("reg-and-log.html",
                                           log="accepted")
        # - - - - - - - - - - - - - - - - - - - - - - - - - #
        if request.form.get("log_name"):  # autorization
            log_name, log_pass = request.form.values()
            log = data_correctly(log_name, log_pass)
            if log != "accepted":
                return render_template("reg-and-log.html", log=log)
            else:
                write_bd(log_name, log_pass)
                return render_template("blog_page.html")

    return render_template("reg-and-log.html")


app.run()
